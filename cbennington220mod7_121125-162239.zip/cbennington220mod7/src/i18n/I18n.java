package i18n;

import java.text.DateFormat;
import java.util.*;

/**
 *
 * @author Casey
 */
public class I18n {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String language = "";
        String country = "";
        Locale locale;
        ResourceBundle rb;

        System.out.println("Pick a language: (1) English (2) Spanish (3) French");
        int which = scan.nextInt();

        if (which == 1) {
            language = "en";
            country = "US";
        } else if (which == 2) {
            language = "es";
            country = "ES";
        } else if (which == 3) {
            language = "fr";
            country = "FR";
        }
        locale = new Locale(language, country);
        rb = ResourceBundle.getBundle("i18n.MessagesBundle", locale);
        System.out.println(rb.getString("localeInfo") + "("
                + locale.getDisplayLanguage() + "," + locale.getDisplayCountry() + ").\n");
        System.out.println(rb.getString("welcome"));
        System.out.println(rb.getString("sayThanks"));
        
        DateFormat date = DateFormat.getDateInstance(DateFormat.LONG, locale);
        System.out.println(date.format(new Date()));
    }
}