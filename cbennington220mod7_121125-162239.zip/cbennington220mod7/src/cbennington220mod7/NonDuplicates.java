package cbennington220mod7;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author Casey
 */
class ValueComparator implements Comparator {

    public int compare(Object o1, Object o2) {
        Map.Entry e1 = (Map.Entry) o1;
        Map.Entry e2 = (Map.Entry) o2;
        Integer map = (Integer) e1.getValue();
        Integer second = (Integer) e2.getValue();
        return -map.compareTo(second);
    }
}

public class NonDuplicates {

    public static void main(String[] args) {
        // create HashMap to store String keys and Integer values
        Map< String, Integer> myMap = new HashMap< String, Integer>();

        createMap(myMap); // create map based on user input
        //displayMap(myMap); // display map content

        sortMapByValue(myMap);
        printWords(myMap);
        System.exit(0);
    } // end main

    // create map from user input
    private static void createMap(Map< String, Integer> map) {
        Frame f = new Frame();
        FileDialog foBox = new FileDialog(f, "Reading text file",
                FileDialog.LOAD);
        foBox.setVisible(true);
        String foName = foBox.getFile();
        String dirPath = foBox.getDirectory();

        File inFile = new File(dirPath + foName);
        ArrayList<String> text = new ArrayList<String>();
        BufferedReader in = null;
        String input = null;
        try {
            in = new BufferedReader(new FileReader(inFile));
            while ((input = in.readLine()) != null) {
                text.add(input);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (EOFException ex) {
            System.out.println("End of file reached.");
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } finally {
            try {
                in.close();
            } catch (IOException ex) {
            }
        }// note the {} - means "do nothing".  should be closed anyway.

        String input2 = text.toString();
        System.out.println("File read."); // prompt for user input
        input2 = input2.replaceAll("\\W", " ");
        String[] tokens = input2.split(" ");

        // processing input text 
        for (String token : tokens) {
            String word = token.toLowerCase(); // get lowercase word
            if (word.equals("")) {
                continue;
            }
            // if the map contains the word
            if (map.containsKey(word)) // is word in map
            {
                int count = map.get(word); // get current count
                map.put(word, count + 1); // increment count
            } else {
                map.put(word, 1); // add new word with a count of 1 to map
            }
        }
    } // end method createMap

    // display map content
    private static void displayMap(Map< String, Integer> map) {
        Set< String> keys = map.keySet(); // get keys

        // sort keys
        TreeSet< String> sortedKeys = new TreeSet< String>(keys);
        System.out.println("\nMap contains:\nKey\t\tValue");

        // generate output for each key in map
        for (String key : sortedKeys) {
            System.out.printf("%-10s%10s\n", key, map.get(key));
        }
    } // end method displayMap

    public static void sortMapByValue(Map<String, Integer> map) {
        System.out.println("File Contains: ");
        ArrayList keys = new ArrayList(map.entrySet());
        Collections.sort(keys, new ValueComparator());

        Iterator i = keys.iterator();
        while (i.hasNext()) {
            System.out.println((Map.Entry) i.next());
        }
    }

    public static void printWords(Map<String, Integer> map) {

        int maxWordCount = 0;
        int minWordCount = 99999;
        String maxWord = null;
        String minWord = null;

        //ArrayList keys = new ArrayList(map.entrySet());

        for (String key : map.keySet()) {
            if (key.length() >= maxWordCount) {
                maxWordCount = key.length();
                maxWord = key;
            }
        }
        System.out.println("The longest word is: ");
        System.out.println(maxWord);

        for (String key : map.keySet()) {
            if (key.length() <= minWordCount) {
                minWordCount = key.length();
                minWord = key;
            }
        }
        System.out.println("The shortest word is: ");
        System.out.println(minWord);
    }
} // end class WordTypeCount