package cbennington220mod7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author Casey
 */
public class SortShuffle {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<Integer> numbers = new ArrayList<Integer>();
        System.out.println("Welcome!  Please enter you numbers (Enter 999 to stop): ");

        int number = 0;
        while (number != 999) {
            System.out.println("Please enter your next number: ");
            number = scan.nextInt();
            if (number == 999) {
                continue;
            }
            numbers.add(number);
        }

        int choice = 0;
        while (choice >= 0) {
            choice = menu();

            if (choice == 1) {
                sortNumbers(numbers);
            } else if (choice == 2) {
                shuffleNumbers(numbers);
            } else if (choice == 3) {
                reverseNumbers(numbers);
            } else if (choice == 4) {
                System.exit(0);
            }
        }
    }

    public static int menu() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Choice:");
        System.out.println("   1. Sort Numbers.");
        System.out.println("   2. Shuffle Numbers.");
        System.out.println("   3. Reverse Numbers.");
        System.out.println("   4. Quit.");
        System.out.println("\n CHOICE:");
        int value = scan.nextInt();
        return value;
    }

    public static void sortNumbers(ArrayList<Integer> numbers) {
        Collections.sort(numbers);
        printArrayList(numbers);
    }

    public static void shuffleNumbers(ArrayList<Integer> numbers) {
        Collections.shuffle(numbers);
        printArrayList(numbers);
    }

    public static void reverseNumbers(ArrayList<Integer> numbers) {
        Collections.reverse(numbers);
        printArrayList(numbers);
    }

    public static void printArrayList(ArrayList<Integer> numbers) {
        System.out.println("Numbers:");
        for (int i = 0; i < numbers.size(); i++) {
            System.out.println(numbers.get(i));
        }
    }
}