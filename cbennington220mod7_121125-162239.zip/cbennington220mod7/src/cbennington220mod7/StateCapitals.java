package cbennington220mod7;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author Casey
 */
public class StateCapitals {

    public static void main(String[] args) {

        Frame f = new Frame();
        FileDialog foBox = new FileDialog(f, "Reading text file",
                FileDialog.LOAD);
        foBox.setVisible(true);
        String foName = foBox.getFile();
        String dirPath = foBox.getDirectory();

        File inFile = new File(dirPath + foName);
        // Location of file to read
        // create HashMap to store String keys and String values
        Map< String, String> states = new HashMap< String, String>();
        BufferedReader in = null;

        try {
            // create a BufferedReader to use to read in the file
            in = new BufferedReader(new FileReader(inFile));

            // read in the first entire line from the file
            String line = in.readLine();
            // continue until the line is null (ie you are at the end of the file)
            while (line != null) {
                // create a StringTokenizer instance that will break the line apart at each , symbols
                // NOTE: the second parameter is the symbols used to separate fields
                StringTokenizer t = new StringTokenizer(line, "-");

                // it gets here if it is a baseball object.
                // Now get each token and put it in a variable
                String state = t.nextToken().trim();
                String capital = t.nextToken().trim();

                states.put(state, capital);

                // read in the next line
                line = in.readLine();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (EOFException ex) {
            System.out.println("End of file reached.");
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } finally {
            try {
                in.close();
            } catch (Exception e) {
            }   // note the {} - means "do nothing".  should be closed anyway.
        }
        //displayMap(states, "Caps:");
        displayRandom(states);
        System.exit(0);
    } // end main

    // display map content
    private static void displayMap(Map< String, String> map, String type) {
        System.out.println(type);

        // generate output for greatest key in map
        for (Map.Entry<String, String> keys : map.entrySet()) {
            System.out.println(keys.getKey() + ": " + keys.getValue());
        }
    } // end method displayMap

    // display random state
    private static void displayRandom(Map< String, String> map) {

        int rightCount = 0;
        int wrongCount = 0;
        Boolean again = true;
        while (again == true) {
            System.out.println("Welcome to the Capital Guessing game!");
            Scanner scan = new Scanner(System.in);

            Random generator = new Random();
            Object[] keys = map.keySet().toArray();
            String randomKey = (String) keys[generator.nextInt(keys.length)];
            System.out.println("What is the name of the Capital for the following State:");
            System.out.println(randomKey);

            String guess = scan.nextLine();

            String randomValue = map.get(randomKey);
            System.out.println(randomValue);
            if (guess.equalsIgnoreCase(randomValue)) {
                System.out.println("You are correct!");
                rightCount++;
            } else {
                System.out.println("You are incorrect!");
                wrongCount++;
            }

            System.out.println("Would you like to play the Capital Guessing game again?(True/False)");
            try {
                again = scan.nextBoolean();
            } catch (InputMismatchException ime) {
                System.out.println("Only enter true or false.");
            }
        }
        System.out.println("You got " + rightCount + " correct.");
        System.out.println("You got " + wrongCount + " incorrect.");
        System.out.println("Thank you!  Come again!");
    } // end method displayMap
}