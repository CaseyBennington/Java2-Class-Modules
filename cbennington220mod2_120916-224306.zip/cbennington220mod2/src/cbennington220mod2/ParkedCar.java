package cbennington220mod2;

/**
 *
 * @author Casey
 */
public class ParkedCar {

    private String make;
    private String licenseNum;
    private int numMinutes;
    private ParkingMeter pm;

    public ParkedCar(String m, String l, int n, ParkingMeter p) {
        make = m;
        licenseNum = l;
        numMinutes = n;
        pm = p;
    }

    public ParkedCar() {
    }

    public String toString() {
        return make + " with license # " + licenseNum + " parked for " + numMinutes + " at " + pm.toString();
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getLicenseNum() {
        return licenseNum;
    }

    public void setLicenseNum(String licenseNum) {
        this.licenseNum = licenseNum;
    }

    public int getNumMinutes() {
        return numMinutes;
    }

    public void setNumMinutes(int numMinutes) {
        this.numMinutes = numMinutes;
    }

    public ParkingMeter getPm() {
        return pm;
    }

    public void setPm(ParkingMeter pm) {
        this.pm = pm;
    }
}