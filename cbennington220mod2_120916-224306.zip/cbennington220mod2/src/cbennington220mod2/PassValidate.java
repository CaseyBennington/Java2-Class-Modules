package cbennington220mod2;

import java.util.Scanner;

/**
 *
 * @author Casey
 */
public class PassValidate {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Give me a password:");
        String pword = scanner.nextLine();
        //String pword = "HoiKK78^%m!";

        System.out.println("Number of characters(@ 4 each): " + numChar(pword));
        System.out.println("Number of upper case letters (@ 2 each): " + numUpper(pword));
        System.out.println("Number of lower case letters (@ 1 each): " + numLower(pword));
        System.out.println("Number of digits (@ 4 each): " + numDigits(pword));
        System.out.println("Number of symbols (@ 1 each): " + numSymbols(pword));
        System.out.println("Number of digits or symbols that are not on the end (@ 1 extra point each): " + numNotOnEnd(pword));
        System.out.println("Penalty of not being at least 8 characters (@ 10): " + lengthPenalty(pword));
        System.out.println("2 point penalty for each consecutive upper or lower case letter sets (@ -2 each): " + consecDeduct(pword));
        System.out.println("Total score is: " + score(pword));

        if (score(pword) >= 76) {
            System.out.println("Your password is EXCEPTIONAL!");
        } else if (score(pword) >= 51) {
            System.out.println("Your password is STRONG!");
        } else if (score(pword) >= 25) {
            System.out.println("Your password is MODERATE.");
        } else {
            System.out.println("Your password is weak! Fix that shiz");
        }
    }

    public static int score(String string) {
        int points = 0;
        points = numChar(string) + numUpper(string) + numLower(string) + numDigits(string) + numSymbols(string) + numNotOnEnd(string) + lengthPenalty(string) + consecDeduct(string);
        return points;
    }

    public static int numChar(String string) {
        int points = 0;
        int length = string.length();
        points = length * 4;
        return points;
    }

    public static int numUpper(String string) {
        int points = 0;
        int upperCaseCount = 0;
        for (int i = 0; i < string.length(); i++) {
            for (char c = 'A'; c <= 'Z'; c++) {
                if (string.charAt(i) == c) {
                    upperCaseCount++;
                }
            }
        }
        points = upperCaseCount * 2;
        return points;
    }

    public static int numLower(String string) {
        int points = 0;
        int lowerCase = 0;
        for (int i = 0; i < string.length(); i++) {
            if (Character.isLowerCase(string.charAt(i))) {
                lowerCase++;
            }
        }
        points = lowerCase;
        return points;
    }

    public static int numDigits(String string) {
        int points = 0;
        int hasNum = 0;
        for (int i = 0; i < string.length(); i++) {
            if (string.charAt(i) >= '0' && string.charAt(i) <= '9') {
                hasNum++;
            }
        }
        points = hasNum * 4;
        return points;
    }

    public static int numSymbols(String string) {
        int points = 0;
        int symbols = string.length() - (numDigits(string) / 4) - (numLower(string)) - (numUpper(string) / 2);
        points = symbols;
        return points;
    }

    public static int numNotOnEnd(String string) {
        int points = 0;
        String s = string.substring(1, string.length() - 1);
        points = s.length() - numLower(s) - (numUpper(s) / 2);
        return points;
    }

    public static int lengthPenalty(String string) {
        int points = 0;
        if (string.length() < 8) {
            points = -10;
        }
        return points;
    }

    public static int consecDeduct(String string) {
        int count = 0;
        int points = 0;
        for (int i = 1; i < string.length(); i++) {
            if (Character.isUpperCase(string.charAt(i)) && Character.isUpperCase(string.charAt(i - 1)) || Character.isLowerCase(string.charAt(i)) && Character.isLowerCase(string.charAt(i - 1))) {
                count++;
            }
        }
        points = count * (-2);
        return points;
    }
}