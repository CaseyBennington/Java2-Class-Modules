package cbennington220mod2;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Casey
 */
public class ParkingSimulator {

    public static void main(String[] args) {
        ArrayList<ParkedCar> pCar = new ArrayList<ParkedCar>();
        ArrayList<ParkingMeter> meter = new ArrayList<ParkingMeter>();
        ArrayList<PoliceOfficer> officer = new ArrayList<PoliceOfficer>();
        ArrayList<ParkingTicket> ticket = new ArrayList<ParkingTicket>();

        loadData(officer, meter, pCar);

        Random randomNum = new Random();

        for (ParkedCar car : pCar) {
            PoliceOfficer pOfficer = officer.get(randomNum.nextInt(officer.size()));
            System.out.println(car.getMake() + " with license # " + car.getLicenseNum() + " parked for " + car.getNumMinutes() + " minutes at " + car.getPm().getMeterNumber() + " with a maximum time limit of " + car.getPm().getNumMinutesMax() + " minutes.");

            if ((car.getNumMinutes() - car.getPm().getNumMinutesMax()) > 0) {
                ParkingTicket pTix = new ParkingTicket(car, pOfficer, car.getNumMinutes() - car.getPm().getNumMinutesMax());
                pTix.reportTicket();
                ticket.add(pTix);
            } else {
                System.out.println("No violation.");
            }
            System.out.println(pOfficer.toString() + ".");
            System.out.println();
        }

        System.out.println("Summary of tickets:");

        for (ParkingTicket tix : ticket) {
            System.out.println(tix.toString());
        }
    }

    public static void loadData(ArrayList<PoliceOfficer> po, ArrayList<ParkingMeter> pm, ArrayList<ParkedCar> pc) {
        po.add(new PoliceOfficer("Joe", "PO123"));
        po.add(new PoliceOfficer("Mike", "PO866"));
        po.add(new PoliceOfficer("Suzie", "PO956"));
        po.add(new PoliceOfficer("Sam", "PO812"));

        pm.add(new ParkingMeter(90, "PM1"));
        pm.add(new ParkingMeter(60, "PM2"));
        pm.add(new ParkingMeter(30, "PM3"));
        pm.add(new ParkingMeter(10, "PM4"));
        pm.add(new ParkingMeter(90, "PM5"));
        pm.add(new ParkingMeter(60, "PM6"));

        pc.add(new ParkedCar("VW", "N34234", 60, pm.get(0)));
        pc.add(new ParkedCar("Mazda", "234-567", 70, pm.get(1)));
        pc.add(new ParkedCar("Subaru", "HelloKitty", 45, pm.get(2)));
        pc.add(new ParkedCar("Buick", "W879HY4", 20, pm.get(3)));
        pc.add(new ParkedCar("Miata", "BG65RF7", 125, pm.get(4)));
        pc.add(new ParkedCar("Corvette", "JI9987", 10, pm.get(5)));
        pc.add(new ParkedCar("Chevy", "12AS76", 145, pm.get(1)));
        pc.add(new ParkedCar("VW", "MK987", 170, pm.get(2)));
        pc.add(new ParkedCar("Dodge", "JR4534D", 86, pm.get(3)));
        pc.add(new ParkedCar("Ford", "C56FDS", 60, pm.get(4)));
    }
}