package cbennington220mod2;

/**
 *
 * @author Casey
 */
public class ParkingMeter {

    private int numMinutesMax;
    private String meterNumber;

    public ParkingMeter(int n, String m) {
        numMinutesMax = n;
        meterNumber = m;
    }

    public ParkingMeter() {
    }

    public String toString() {
        return meterNumber + " and a maximum time limit of " + numMinutesMax + " minutes";
    }

    public int getNumMinutesMax() {
        return numMinutesMax;
    }

    public void setNumMinutesMax(int numMinutesMax) {
        this.numMinutesMax = numMinutesMax;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(String meterNumber) {
        this.meterNumber = meterNumber;
    }
}