package cbennington220mod2;

import java.util.Scanner;

/**
 *
 * @author Casey
 */
public class SwitchIt {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Put in a number to switch:");
        String myString = scan.nextLine();
        char yes[] = myString.toCharArray();

        for (int w = 0; w < yes.length; w++) {
            if (!Character.isDigit(yes[w])) {
                System.out.println("Not a valid number!");
                System.exit(0);
            }
        }

        if (myString.length() % 2 != 0) {
            System.out.println("Odd");
            for (int i = 0; i < yes.length - 1; i = i + 2) {
                char temp = yes[i];
                yes[i] = yes[i + 1];
                yes[i + 1] = temp;
            }
            System.out.println(yes);

        } else {
            System.out.println("Even");
            for (int i = 0; i < yes.length; i = i + 2) {
                char temp = yes[i];
                yes[i] = yes[i + 1];
                yes[i + 1] = temp;
            }
            System.out.println(yes);
        }
    }
}
