package cbennington220mod2;

import java.text.NumberFormat;

/**
 *
 * @author Casey
 */
public class ParkingTicket {

    private int minutesOver;
    private double fine;
    private ParkedCar pk;
    private PoliceOfficer po;

    public ParkingTicket(ParkedCar k, PoliceOfficer o, int m) {
        minutesOver = m;
        pk = k;
        po = o;
    }

    public ParkingTicket() {
    }

    public void reportTicket() {
        NumberFormat money = NumberFormat.getCurrencyInstance();
        double multiplier = Math.ceil((double) minutesOver / 60);

        if (multiplier >=1){
            fine = 25+ (multiplier -1) * 10;
        }
        else{
            fine = 0;
        }
        System.out.println("Car was parked illegally for " + minutesOver + " minutes for a fine of " + money.format(fine) + ".");
    }

    public String toString() {
        NumberFormat money = NumberFormat.getCurrencyInstance();
        return "License: " + pk.getLicenseNum() + "at meter #: " + pk.getPm().getMeterNumber() + ": Fine: " + money.format(fine);
    }

    public ParkedCar getPk() {
        return pk;
    }

    public void setPk(ParkedCar pk) {
        this.pk = pk;
    }

    public PoliceOfficer getPo() {
        return po;
    }

    public void setPo(PoliceOfficer po) {
        this.po = po;
    }
}