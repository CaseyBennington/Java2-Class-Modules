package cbennington220mod2;

/**
 *
 * @author Casey
 */
public class PoliceOfficer {

    private String name;
    private String badgeNum;

    public PoliceOfficer(String n, String b) {
        name = n;
        badgeNum = b;
    }

    public PoliceOfficer() {
    }

    public String toString() {
        return "Reported by officer " + name + " badge:  " + badgeNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBadgeNum() {
        return badgeNum;
    }

    public void setBadgeNum(String badgeNum) {
        this.badgeNum = badgeNum;
    }
}