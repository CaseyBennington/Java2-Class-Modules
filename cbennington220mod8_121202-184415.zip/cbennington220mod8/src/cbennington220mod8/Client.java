package cbennington220mod8;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.io.*;
import java.net.*;
import java.awt.event.*;
import java.text.NumberFormat;
import java.util.StringTokenizer;
import javax.swing.*;

public class Client extends JFrame implements ActionListener {

    private JTextField rateField, yearsField, amountField;
    private JFormattedTextField paymentField, totalPaymentField;
    private JLabel amountLabel, rateLabel, yearsLabel, paymentLabel, totalPaymentLabel;
    private JButton calculateButton, exitButton, clearButton;
    private double annualInterestRate;
    private int numOfYears;
    private double loanAmount;
    private NumberFormat paymentFormat;
    PrintWriter osToServer;
    BufferedReader isFromServer;

    public static void main(String[] args) {
        JFrame frame = new Client();
        frame.show();
    }

    public Client() {
        setUpFormats();
        setTitle("Loan Calculator");
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension d = tk.getScreenSize();
        int width = 267;
        int height = 250;
        setBounds((d.width - width) / 2, (d.height - height) / 2, width, height);
        setResizable(false);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        JPanel displayPanel = new JPanel();
        displayPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        amountLabel = new JLabel("Loan Amount:");
        rateLabel = new JLabel("Interest Rate:");
        yearsLabel = new JLabel("Number of Years:");
        paymentLabel = new JLabel("Monthly Payment:");
        totalPaymentLabel = new JLabel("Total Payment:");
        amountField = new JTextField(10);
        rateField = new JTextField(10);
        yearsField = new JTextField(10);
        paymentField = new JFormattedTextField(paymentFormat);
        paymentField.setColumns(10);
        totalPaymentField = new JFormattedTextField(paymentFormat);
        totalPaymentField.setColumns(10);
        paymentField.setEditable(false);
        totalPaymentField.setEditable(false);
        displayPanel.add(amountLabel);
        displayPanel.add(amountField);
        displayPanel.add(rateLabel);
        displayPanel.add(rateField);
        displayPanel.add(yearsLabel);
        displayPanel.add(yearsField);
        displayPanel.add(paymentLabel);
        displayPanel.add(paymentField);
        displayPanel.add(totalPaymentLabel);
        displayPanel.add(totalPaymentField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        calculateButton = new JButton("Calculate");
        exitButton = new JButton("Exit");
        clearButton = new JButton("Clear");
        buttonPanel.add(calculateButton);
        buttonPanel.add(exitButton);
        buttonPanel.add(clearButton);

        calculateButton.addActionListener(this);
        exitButton.addActionListener(this);
        clearButton.addActionListener(this);

        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(displayPanel, BorderLayout.CENTER);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);

        try {
            // Create a socket to connect to the server
            Socket connectToServer = new Socket("localhost", 8005);

            // Create a buffered input stream to receive data
            // from the server
            isFromServer = new BufferedReader(
                    new InputStreamReader(connectToServer.getInputStream()));

            // Create a buffered output stream to send data to the server
            osToServer =
                    new PrintWriter(connectToServer.getOutputStream(), true);
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    private void setUpFormats() {
         paymentFormat = NumberFormat.getCurrencyInstance();
    }

    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == exitButton) {
            System.exit(0);
        } else if (source == calculateButton) {
            paymentField.setText("");
            paymentField.setEditable(false);
            totalPaymentField.setEditable(false);
            amountField.setEditable(true);
            amountField.requestFocus();
            try {
                // Read the input from the keyboard
                annualInterestRate = Double.parseDouble(rateField.getText());
                numOfYears = Integer.parseInt(yearsField.getText());
                int months = numOfYears * 12;
                NumberFormat mf = NumberFormat.getCurrencyInstance();
                loanAmount = Double.parseDouble(amountField.getText());

                // Send input to the server
                osToServer.println(loanAmount + " " + annualInterestRate + " " + months);

                // Get payment amount from the server
                StringTokenizer st = new StringTokenizer(
                        isFromServer.readLine(), " ");

                // Convert string to double
                String payment = new String(
                        st.nextToken()).toString();
                String totalPayment = new String(st.nextToken()).toString();

                // Print area on
                paymentField.setText(payment);
                totalPaymentField.setText(totalPayment);

            } catch (IOException ex) {
                System.err.println(ex);
            }
        } else if (source == clearButton) {
            amountField.setText("");
            rateField.setText("");
            yearsField.setText("");
            paymentField.setText("");
            totalPaymentField.setText("");
        }
    }
}