package cbennington220mod8;

import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import javax.swing.*;

public class Server extends JFrame {

    private JTextArea jta = new JTextArea();

    public static void main(String[] args) {
        new Server();
    }

    public Server() {
        // Place text area on the frame
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(new JScrollPane(jta), BorderLayout.CENTER);

        // It is necessary to show the frame here!
        setTitle("I am the Server");
        setSize(500, 300);
        setVisible(true);

        try {
            // Create a server socket
            ServerSocket s = new ServerSocket(8005);
            jta.append("Server started at " + new Date() + '\n');

            // Label a thread
            int i = 0;

            while (true) {
                // Listen for a new connection request
                Socket connectToClient = s.accept();

                // Print the new connect number on the console
                jta.append("Starting thread " + i + " at " + new Date() + '\n');

                // Create a new thread for the connection
                ThreadHandler t = new ThreadHandler(connectToClient, i);

                // Start the new thread
                t.start();

                // Increment i to label the next connection
                i++;
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

// Inner class
// Define the thread class for handling new connection
    class ThreadHandler extends Thread {

        private Socket connectToClient; // A connected socket
        private int counter; // Label for the connection

        public ThreadHandler(Socket c, int i) {
            connectToClient = c;
            counter = i;
        }

        public void run() {
            try {
                // Create data input and print streams
                BufferedReader isFromClient = new BufferedReader(
                        new InputStreamReader(connectToClient.getInputStream()));
                PrintWriter osToClient =
                        new PrintWriter(connectToClient.getOutputStream(), true);

                // Continuously serve the client
                while (true) {
                    DecimalFormat decimal = new DecimalFormat("0.00");
                    NumberFormat mf = NumberFormat.getCurrencyInstance();
                    // Receive data from the client in string
                    StringTokenizer st = new StringTokenizer(isFromClient.readLine(), " ");

                    // Get input
                    double amount = new Double(st.nextToken()).doubleValue();
                    jta.append("amount received from client: " + mf.format(amount) + '\n');
                    double interestRate = new Double(st.nextToken()).doubleValue();
                    jta.append("interest rate received from client: " + decimal.format(interestRate) + '\n');
                    int months = new Integer(st.nextToken()).intValue();
                    jta.append("rate received from client: " + months + '\n');

                    // Compute payments
                    double monthlyInterest = interestRate / 12 / 100;
                    double payment = FinancialCalculations.calculateMonthlyPayment(
                            amount, months, monthlyInterest);
                    double totalPayment = FinancialCalculations.calculateFutureValue(payment, months, monthlyInterest);

                    // Send payments back to the client
                    osToClient.println((mf.format(payment)) + " " + (mf.format(totalPayment)));
                    jta.append("Monthly Payment calculated: " + mf.format(payment) + '\n');
                    jta.append("Total Payment calculated: " + mf.format(totalPayment) + '\n');
                }
            } catch (IOException e) {
                System.err.println(e);
            }
        }
    }
}