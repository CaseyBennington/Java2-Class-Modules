package cbennington220mod3;

/**
 *
 * @author Casey
 */
public class SavingsAccount extends Account {

    protected double intRate; //I believe you ment this to be private in your UML, but I think any specific savings account that would extend this class would for sure have an intrate.

    public SavingsAccount(Customer cust, Double bal, Day day, Double rate) {
        super(cust, bal, day);
        intRate = rate;
        acctNum = nextNum;
        nextNum++;
    }

    public SavingsAccount() {
    }

    public String toString() {
        return (super.toString() + " with a savings account interest of " + getIntRate() + ".");
    }

    public double getIntRate() {
        return intRate;
    }

    public void setIntRate(double intRate) {
        this.intRate = intRate;
    }
}