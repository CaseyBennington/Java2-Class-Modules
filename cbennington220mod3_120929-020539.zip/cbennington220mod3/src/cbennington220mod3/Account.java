package cbennington220mod3;

import java.text.NumberFormat;

/**
 *
 * @author Casey
 */
public abstract class Account implements Comparable<Account> {

    protected Customer customer;
    protected double balance;
    protected int acctNum;
    protected Day dateOpened;
    NumberFormat currency = NumberFormat.getCurrencyInstance();
    // a static variable used to make the insurance id unique
    public static int nextNum = 1000;

    // full constructor - automatically creates a new Insurance id
    public Account(Customer cust, Double bal, Day day) {
        customer = cust;
        balance = bal;
        dateOpened = day;
        acctNum = nextNum;
        nextNum++;
    }

    // the empty constructor but still sets a unique id
    public Account() {
        balance = nextNum;
        nextNum++;
    }

    public String toString() {
        return (customer.toString() + " has an account number of " + acctNum + " with a balance of " + currency.format(balance) + " opened on " + dateOpened) + ".";
    }

    public int compareTo(Account acct) {
        if (this.getBalance() > acct.getBalance()) {
            return 1;
        } else if (this.getBalance() < acct.getBalance()) {
            return -1;
        } else {
            return 0;
        }
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public int getAcctNum() {
        return acctNum;
    }

    public void setAcctNum(int acctNum) {
        this.acctNum = acctNum;
    }

    public Day getDateOpened() {
        return dateOpened;
    }

    public void setDateOpened(Day dateOpened) {
        this.dateOpened = dateOpened;
    }
}