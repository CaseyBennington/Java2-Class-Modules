package cbennington220mod3;

public class Money {

    private String name;
    private double value;

    // constructors, toString, getters and setters
    public Money(String n, Double v) {
        name = n;
        value = v;
    }

    public Money() {
    }

    @Override
    public String toString() {
        return "Money{" + "name=" + name + ", value=" + value + '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }
}