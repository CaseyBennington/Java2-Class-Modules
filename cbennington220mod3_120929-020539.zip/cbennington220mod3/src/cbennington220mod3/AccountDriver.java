package cbennington220mod3;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Casey
 */
public class AccountDriver {

    public static void main(String[] args) {

        ArrayList<Customer> cust = new ArrayList<Customer>();
        ArrayList<Account> acct = new ArrayList<Account>();

        loadData(cust, acct);
        System.out.println("Originial Data");
        print(acct);
        System.out.println("Sorted Balance Data");
        printSortedBalance(acct);
        System.out.println("Sorted Name Data");
        printSortedName(acct);
        System.out.println("Sorted ID Data");
        printSortedID(acct);
    }

    public static void loadData(ArrayList<Customer> c, ArrayList<Account> acct) {
        Day one = new Day(2012, 4, 12);
        Day two = new Day(2012, 9, 22);
        Customer c0 = new Customer("Jones", "Sam");
        Customer c1 = new Customer("Miller", "Joe");
        Customer c2 = new Customer("Johnson", "Debi");
        Customer c3 = new Customer("Smith", "Mike");
        Customer c4 = new Customer("Crouch", "James");
        c.add(c0);
        c.add(c1);
        c.add(c2);
        c.add(c3);
        c.add(c4);

        acct.add(new CheckingAccount(c0, 45000.00, one, 4.00));
        acct.add(new SavingsAccount(c1, 2000.00, one, 2.2));
        acct.add(new SavingsAccount(c2, 1100.00, one, 1.8));
        acct.add(new CheckingAccount(c3, 22000.00, two, 8.0));
        acct.add(new SuperSavings(c4, 45000.00, one, 6.5, 20000.00));
        acct.add(new CheckingAccount(c4, 1200.00, one, 4.0));
        acct.add(new SuperSavings(c0, 28000.00, one, 6.8, 20000.00));
    }

    public static void print(ArrayList<Account> acct) {
        for (Account acctl : acct) {
            System.out.println(acctl.toString());
        }
    }

    public static void printSortedBalance(ArrayList<Account> acct) {
        Collections.sort(acct);
        print(acct);
    }

    public static void printSortedName(ArrayList<Account> acct) {
        Collections.sort(acct, new NameComparator());
        print(acct);
    }

    public static void printSortedID(ArrayList<Account> acct) {
        Collections.sort(acct, new AccountIDComparator());
        print(acct);
    }
}