package cbennington220mod3;

import java.util.Comparator;

/**
 *
 * @author Casey
 */
class NameComparator implements Comparator<Account> {

    public int compare(Account acct1, Account acct2) {

        if ((acct1.getCustomer().getLast() + acct1.getCustomer().getFirst()).compareTo(acct2.getCustomer().getLast() + acct2.getCustomer().getFirst()) > 0) {
            return 1;
        } else if ((acct1.getCustomer().getLast() + acct1.getCustomer().getFirst()).compareTo((acct2.getCustomer().getLast() + acct2.getCustomer().getFirst())) < 0) {
            return -1;
        } else {
            return 0;
        }
    }
}