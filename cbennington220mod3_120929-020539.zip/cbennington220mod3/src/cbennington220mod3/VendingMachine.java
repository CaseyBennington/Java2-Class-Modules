package cbennington220mod3;

import java.util.ArrayList;

public class VendingMachine {

    private ArrayList<VendingItem> items;
    private ArrayList<Money> moneyTypes;

    public VendingMachine(ArrayList item, ArrayList mon) {
        items = item;
        moneyTypes = mon;
    }

    public VendingMachine() {
    }

// you want to load the items in the machine and load the known money types
// here are the methods that I used.
// I also used a method to list the names of the money types you might want
//you can uncomment these
    public void loadMachine() {
        items = new ArrayList<VendingItem>();
        items.add(new VendingItem("Coke", 1.00));
        items.add(new VendingItem("Sprit", 1.20));
        items.add(new VendingItem("Gatorade", 1.40));
        items.add(new VendingItem("Water", 0.80));
    }

    public void createMoney() {
        moneyTypes = new ArrayList<Money>();
        moneyTypes.add(new Money("penny", .01));
        moneyTypes.add(new Money("nickel", .05));
        moneyTypes.add(new Money("dime", 0.10));
        moneyTypes.add(new Money("quarter", 0.25));
        moneyTypes.add(new Money("dollar", 1.00));
        moneyTypes.add(new Money("five", 5.00));
        moneyTypes.add(new Money("ten", 10.00));

    }

    public String toStringMoneyTypes() {
        String output = "";
        for (int i = 0; i < moneyTypes.size(); i++) {
            output = output + moneyTypes.get(i).getName() + "\n";
        }
        return output;
    }

    public String toStringItemTypes() {
        String output = "";
        for (int i = 0; i < items.size(); i++) {
            output = output + (i + 1) + ". Product=" + items.get(i).getProduct();
            output = output + ", price=" + items.get(i).getPrice() + "\n";
        }
        return output;
    }

    public ArrayList<VendingItem> getItems() {
        return items;
    }

    public void setItems(ArrayList<VendingItem> items) {
        this.items = items;
    }

    public ArrayList<Money> getMoneyTypes() {
        return moneyTypes;
    }

    public void setMoneyTypes(ArrayList<Money> moneyTypes) {
        this.moneyTypes = moneyTypes;
    }
}