package cbennington220mod3;

/**
 *
 * @author Casey
 */
public class SuperSavings extends SavingsAccount {

    private double minDeposit;

    public SuperSavings(Customer cust, Double bal, Day day, Double rate, Double deposit) {
        super(cust, bal, day, rate);
        minDeposit = deposit;
        acctNum = nextNum;
        nextNum++;
    }

    public SuperSavings() {
    }

    public String toString() {
        return (super.toString() + " with a minimum deposit of " + getIntRate() + ".");
    }

    public double getMinDeposit() {
        return minDeposit;
    }

    public void setMinDeposit(double minDeposit) {
        this.minDeposit = minDeposit;
    }
}