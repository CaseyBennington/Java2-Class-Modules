package cbennington220mod3;

/**
 *
 * @author Casey
 */
public class CheckingAccount extends Account {

    private double monthlyFee;

    public CheckingAccount(Customer cust, Double bal, Day day, Double fee) {
        super(cust, bal, day);
        monthlyFee = fee;
        acctNum = nextNum;
        nextNum++;
    }

    public CheckingAccount() {
    }

    public String toString() {
        return (super.toString() + " with a monthly fee of " + currency.format(getMonthlyFee()) + ".");
    }

    public double getMonthlyFee() {
        return monthlyFee;
    }

    public void setMonthlyFee(double monthlyFee) {
        this.monthlyFee = monthlyFee;
    }
}