package cbennington220mod3;

import java.util.Comparator;

/**
 *
 * @author Casey
 */
class AccountIDComparator implements Comparator<Account> {

    public int compare(Account acct1, Account acct2) {

        int acct1ID =  acct1.getAcctNum();
        int acct2ID =  acct2.getAcctNum();

        if (acct1ID > acct2ID) {
            return 1;
        } else if (acct1ID < acct2ID) {
            return -1;
        } else {
            return 0;
        }
    }
}