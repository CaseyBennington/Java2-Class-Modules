package cbennington220mod3;

public class VendingItem {

    private String product;
    private double price;

    public VendingItem(String pro, Double p) {
        product = pro;
        price = p;
    }

    public VendingItem() {
    }

    @Override
    public String toString() {
        return "VendingItem{" + "product=" + product + ", price=" + price + '}';
    }

    // constructors, toString, and getters and setters
    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}