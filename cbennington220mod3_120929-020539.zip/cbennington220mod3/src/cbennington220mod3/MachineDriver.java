package cbennington220mod3;

import java.text.DecimalFormat;
import java.util.Scanner;

public class MachineDriver {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        DecimalFormat money = new DecimalFormat("$0.00");
        VendingMachine vending = new VendingMachine();
        vending.loadMachine();
        vending.createMoney();

        // create a loop for making a purchase

        boolean moreProducts = true;
        boolean more = true;
        while (moreProducts == true) {
            System.out.println(vending.toStringItemTypes());
            Purchase purchase = new Purchase();
            purchase.recordPurchase(vending);
            while (more == true && (purchase.getPaymentSoFar() < purchase.getCost())) {

                //while (purchase.getPaymentSoFar() < purchase.getCost()) {
                // inside create a loop that makes multiple payments on that purchase
                // this should allow them to continue to add until they pay enough
                // or give them their money back.
                System.out.println("Here are you choices for payment:");
                System.out.println(vending.toStringMoneyTypes());
                System.out.println("Which coin or dollar type? (enter the name)");
                String payment = scan.nextLine();
                System.out.println("How many?");
                int amount = scan.nextInt();

                purchase.enterPayment(vending, amount, payment);
                // See sample output

                //}
                if (purchase.getPaymentSoFar() < purchase.getCost()) {
                    System.out.println("More payments? (true/false)");
                    more = scan.nextBoolean();
                    if (more == false) {
                        System.out.println("I guess you do not have enough money so I will refund your " + money.format(purchase.getPaymentSoFar()) + ".");
                    }
                    scan.nextLine();
                }
            }
            System.out.println("More purchases? (true/false)");
            moreProducts = scan.nextBoolean();
            if (moreProducts == false) {
                System.out.println("Thank you, come again!");
            } else {
                more = true;
            }
            scan.nextLine();
        }
    }
}