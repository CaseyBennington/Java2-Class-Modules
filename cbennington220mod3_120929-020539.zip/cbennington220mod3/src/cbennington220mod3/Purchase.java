package cbennington220mod3;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class Purchase {

    private double cost;
    private double paymentSoFar;

    public Purchase(Double pro, Double p) {
        cost = pro;
        paymentSoFar = p;
    }

    public Purchase() {
    }

    public void recordPurchase(VendingMachine vm) {
        // call the toString method of vm
        vm.toStringMoneyTypes();
        // ask them which they want and get their answer
        Scanner scan = new Scanner(System.in);
        System.out.println("Which item would you like (type in the number in the front)?");
        int pick = scan.nextInt();

        // set the value of the cost from the item them pick
        cost = vm.getItems().get(pick - 1).getPrice();
        // set paymentSoFar to zero
        paymentSoFar = 0.00;
    }

    public void enterPayment(VendingMachine vm, int unitCount, String type) {
        DecimalFormat money = new DecimalFormat("$0.00");
        ArrayList<Money> moneyTypes = vm.getMoneyTypes();
        // do a search through the array list for the type String that they entered
        // find it
        int index = 0;
        boolean found = false;
        while (index < moneyTypes.size() && !found) {
            if (moneyTypes.get(index).getName().equalsIgnoreCase(type)) {
                found = true;
                // Otherwise - get it's value and adjust the paymentSoFar field
                paymentSoFar = paymentSoFar + unitCount * moneyTypes.get(index).getValue();
            } else {
                index++;
            }
            // if it is not found, tell them so
            if (index >= moneyTypes.size() && !found) {
                System.out.println("Please enter a correct payment choice!");
                return;
            }
        }
        System.out.println("Paid so far: " + money.format(paymentSoFar));
        if (cost - paymentSoFar >0) {
            System.out.println("Still owed: " + money.format((cost - paymentSoFar)));
        } else {
            System.out.println("Your change is: " + money.format((paymentSoFar - cost)));
        }
    }

    // print out the amount paid so far
    // if something is still owed, print out the amount
    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public double getPaymentSoFar() {
        return paymentSoFar;
    }

    public void setPaymentSoFar(double paymentSoFar) {
        this.paymentSoFar = paymentSoFar;
    }
}