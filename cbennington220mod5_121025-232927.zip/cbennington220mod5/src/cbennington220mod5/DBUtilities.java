package cbennington220mod5;

import java.sql.*;
import java.util.*;

public class DBUtilities {

    private static Connection con;
    private static Statement stmt;
    private static CallableStatement ca;
    private static Scanner scan = new Scanner(System.in);
    private static String name = "worldseries";
    private static String noway = "";

    public static Connection createConnection() {
        String user = "itp220";
        String pass = "itp220";
        con = JDBCConnection.connect(2, user, pass);
        return con;
    }

    public static void closeConnection() {
        if (con != null) {
            try {
                con.close();
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void checkConnect() {
        if (con == null) {
            con = createConnection();
        }
        if (stmt == null) {
            try {
                stmt = con.createStatement();
            } catch (SQLException e) {
                System.out.println("Cannot create the statement");
            }
        }
    }

    //assume that the database already exists
    public static void createTableWorldSeries() {
        System.out.println("What do you want to call your table? (It is stronly urged that you use:  worldseries.  In fact, it is so strongly urged that no matter what you type, it is:  worldseries.");
        noway = scan.nextLine();
        String createStored = "{Call CreateWSTable()}";
        String dropStored = "{Call dropWSTable()}";
        //String query = "CREATE table " + name + " (year int not null, winner varchar(50), league varchar(50), loser varchar(50), primary key (year))";
        //String dropString = "DROP table " + name;
        checkConnect();

        try {
            // drop the table if it exists.  If it does not, it will throw a SQLException
            ca = con.prepareCall(dropStored);
            ResultSet rs = ca.executeQuery();
            //stmt.executeUpdate(dropStored);
            System.out.println(name + " table existed so I dropped it.");

        } catch (SQLException e) {
            // catch that exception and do nothing
            System.out.println(name + " table did not exist so I will create it.");
        }

        try {
            // now create the table
            ca = con.prepareCall(createStored);
            ResultSet rs = ca.executeQuery();
            //stmt.executeUpdate(createStored);
            System.out.println(name + " table created");
        } catch (SQLException e) {
            // will catch bad SQL format
            System.out.println("Execute update error.");
        }
    }

    public static void storeWS(ArrayList<BaseballWSBlueprint> ws) {
        checkConnect();
        for (int i = 0; i < ws.size(); i++) {
            BaseballWSBlueprint bbwsb = ws.get(i);
            
            String stored = "{Call storeWS('" + bbwsb.getYear() + "', '" + bbwsb.getWinner() + "', '" + bbwsb.getLeague() + "', '" + bbwsb.getLoser() + "' )}";
            //String query = "INSERT into " + name + "  VALUES(" + bbwsb.getYear() + ",\'" + bbwsb.getWinner() + "\',\'" + bbwsb.getLeague() + "\',\'" + bbwsb.getLoser() + "\')";
            //System.out.println(query);
            try {
                ca = con.prepareCall(stored);
                ca.executeUpdate();
                //stmt.executeUpdate(query);
            } catch (SQLException e) {
                System.out.println("SQL insert Exception");
            }
        }
    }

    public static void findWTeamYears() {
        System.out.println("Which team?");
        String winner = scan.nextLine();
        checkConnect();

        String find = "{Call findWTeamYears('" + winner + "')}";
        //String query = "SELECT * FROM WorldSeries WHERE winner = '" + winner + "'";
        try {
            ca = con.prepareCall(find);
            ResultSet rs = ca.executeQuery();
            System.out.println(winner + ":");
            while (rs.next()) {
                System.out.println(rs.getString(1));
            }
        } catch (SQLException e) {
            System.out.println("That team does not exist");
        }
    }

    public static void findWinnerTimes() {
        System.out.println("Which team?");
        String winner = scan.nextLine();
        checkConnect();

        String find = "{Call findWTeamYears('" + winner + "')}";
        //String query = "SELECT * FROM WorldSeries WHERE winner = '" + winner + "'";

        try {
            int count = 0;
            ca = con.prepareCall(find);
            ResultSet rs = ca.executeQuery();
            while (rs.next()) {
                count++;  //Could have used SQL to query this count but I actually didn't think of that until after the fact and this works just fine.
            }
            System.out.println(winner + " won the World Series " + count + " times.");
        } catch (SQLException e) {
            System.out.println("That team does not exist");
        }
    }

    public static void listWinners() {
        checkConnect();
        String list = "{Call listWinners()}";
        //String query = "SELECT winner AS Winner, COUNT(winner) AS Times FROM WorldSeries GROUP BY winner ORDER BY COUNT(winner) DESC";

        try {
            ca = con.prepareCall(list);
            ResultSet rs = ca.executeQuery();
            ResultSetMetaData metaData = rs.getMetaData();
            int numberOfColumns = metaData.getColumnCount();
            System.out.println(name + " Table of World Series Database:\n");

            for (int i = 1; i <= numberOfColumns; i++) {
                System.out.printf("%-20s\t", metaData.getColumnName(i));
            }
            System.out.println();

            while (rs.next()) {
                for (int i = 1; i <= numberOfColumns; i++) {
                    System.out.printf("%-20s\t", rs.getObject(i));
                }
                System.out.println();
            } // end while

        } catch (SQLException e) {
            System.out.println("That team does not exist");
        }
    }

    public static void addWinner() {
        checkConnect();
        System.out.println("Please enter your World Series Information as follows:");
        System.out.println("What is the World Series year? (Please enter a new year)");
        int year = scan.nextInt();

        String add = "{Call queryYear()}";
        //String queryYear = "SELECT year FROM WorldSeries ORDER BY year";
        String year2;
        int year3 = 0;
        try {
            ca = con.prepareCall(add);
            ResultSet rs = ca.executeQuery();
            while (rs.next()) {
                year2 = rs.getObject(1).toString();
                year3 = Integer.parseInt(year2);
                if (year == year3) {
                    throw new SQLException();
                }
            }
        } catch (SQLException e) {
            System.out.println("That year has already been entered.  You'll have to try again.");
            return;
        }

        scan.nextLine();
        System.out.println("What is the winning team name?");
        String winner = scan.nextLine();
        System.out.println("What is the winning team's league?");
        String league = scan.nextLine();
        System.out.println("What is the losing team name?");
        String loser = scan.nextLine();

        String stored2 = "{Call addWinner('" + year + "', '" + winner + "', '" + league + "', '" + loser + "' )}";    //ran into issues with dynamically calling table name.
        //String query = "INSERT into WorldSeries  VALUES(" + year + ",\'" + winner + "\',\'" + league + "\',\'" + loser + "\')";

        try {
            ca = con.prepareCall(stored2);
            ca.executeUpdate();
        } catch (SQLException e) {
            System.out.println("SQL insert Exception");
        }
        System.out.println("Thank you for your entry!");
    }
}