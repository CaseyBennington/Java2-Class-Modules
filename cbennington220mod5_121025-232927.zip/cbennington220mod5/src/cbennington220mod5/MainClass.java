package cbennington220mod5;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class MainClass {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<BaseballWSBlueprint> ws = null;
        int ans;
        try {
            while (true) {
                menu();
                System.out.println("CHOICE:");
                ans = scan.nextInt();
                if (ans == 0) {
                    ws = getWS();
                }

                if (ans == 1) {
                    DBUtilities.createTableWorldSeries();
                    try {
                        DBUtilities.storeWS(ws);
                    } catch (Exception e) {
                        System.out.println("There is no data in memory to store");
                    }
                }

                if (ans == 2) {
                    DBUtilities.findWTeamYears();
                }

                if (ans == 3) {
                    DBUtilities.findWinnerTimes();
                }

                if (ans == 4) {
                    DBUtilities.listWinners();
                }

                if (ans == 5) {
                    DBUtilities.addWinner();
                }

                if (ans == 12) {
                    DBUtilities.closeConnection();
                    System.out.println("See you later!");
                    System.exit(0);
                }
            }
        } catch (Exception e) {
            System.out.println("That was bad data entry!  Do it better next time!");
            DBUtilities.closeConnection();
            System.exit(0);
        }
    }

    public static ArrayList<BaseballWSBlueprint> getWS() {
        // Location of file to read
        ArrayList<BaseballWSBlueprint> teams = new ArrayList<BaseballWSBlueprint>();
        //File file = new File("C:\\Users\\Casey\\Desktop\\WorldSeriesWinLose.txt");
        File file = new File("WorldSeriesWinLose.txt");
        BufferedReader in = null;
        int year = 1903;
        try {
            // create a BufferedReader to use to read in the file
            in = new BufferedReader(new FileReader(file));

            // read in the first entire line from the file
            String line = in.readLine();
            // continue until the line is null (ie you are at the end of the file)
            while (line != null) {
                // create a StringTokenizer instance that will break the line apart at each , symbols
                // NOTE: the second parameter is the symbols used to separate fields
                StringTokenizer t = new StringTokenizer(line, ",");

                // it gets here if it is a baseball object.
                // Now get each token and put it in a variable
                String winner = t.nextToken().trim();
                String league = t.nextToken().trim();
                String loser = t.nextToken().trim();
                // create a Baseball instance for the data
                if ((year == 1904) || (year == 1994)) {
                    year++;
                }
                BaseballWSBlueprint b = new BaseballWSBlueprint(year, winner, league, loser);
                // add the instance to the ArrayList
                teams.add(b);
                year++;
                // read in the next line
                line = in.readLine();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (EOFException ex) {
            System.out.println("End of file reached.");
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } finally {
            try {
                in.close();
                DBUtilities.closeConnection();
            } catch (Exception e) {
            }   // note the {} - means "do nothing".  should be closed anyway.
        }
        return teams;
    }

    public static void menu() {
        System.out.println("\n0.  Populate array lists with text file data");
        System.out.println("1.  Create the baseball database table and Save the array list data from memory to the database table");
        System.out.println("2.  Given a team name, list all of the years that they won the World Series");
        System.out.println("3.  Given a team name, list the number of times they won the World Series");
        System.out.println("4.  List the winners of the World Series along with the number of times that they won.  (Descending)");
        System.out.println("5.  Add a new winner (Enter:  Winning team name and league, losing team name, and year.)");
        System.out.println("12.  exit\n");
    }
}