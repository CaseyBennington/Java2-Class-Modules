package cbennington220mod5;



import java.io.Serializable;

/**
 *
 * @author Casey
 */
public class BaseballWSBlueprint implements Serializable {

    private int year;
    private String winner;
    private String league;
    private String loser;

    public BaseballWSBlueprint() {
    }

    public BaseballWSBlueprint(int year, String winner, String league, String loser) {
        this.year = year;
        this.winner = winner;
        this.league = league;
        this.loser = loser;
    }

    @Override
    public String toString() {
        return winner + " of the " + league + " won the World Series in " + year + " against the loser: " + loser;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getWinner() {
        return winner;
    }

    public void setWinner(String winner) {
        this.winner = winner;
    }

    public String getLeague() {
        return league;
    }

    public void setLeague(String league) {
        this.league = league;
    }

    public String getLoser() {
        return loser;
    }

    public void setLoser(String loser) {
        this.loser = loser;
    }
}
