package cbennington220mod4;

import java.text.NumberFormat;

public class Account {

    private int acctNum;
    private double balance;
    private String last;     // this is not the best way to do this as we saw 
    private String first;	 // in the previous module but we want to keep it simple

    public Account() {
    }

    public Account(int a, double b, String l, String f) {
        acctNum = a;
        balance = b;
        last = l;
        first = f;
    }

    public String toString() {
        NumberFormat nf = NumberFormat.getCurrencyInstance();
        return first + " " + last + " has an account number of " + acctNum + " and a balance of " + nf.format(balance);
    }

    public void deposit(double amount) {
        balance = balance + amount;

    }

    public void withdraw(double amount, double fee) {
        if (amount < balance) {
            balance = balance - amount - fee;
        } else {
            System.out.println("You do not have that much in your account. ");
        }

    }

    public int getAcctNum() {
        return acctNum;
    }

    public void setAcctNum(int acctNum) {
        this.acctNum = acctNum;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getFirst() {
        return first;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }
}