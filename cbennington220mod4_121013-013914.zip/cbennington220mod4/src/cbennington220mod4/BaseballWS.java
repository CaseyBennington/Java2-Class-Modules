package cbennington220mod4;
// Program counts the number of occurrences of each word in a String.

/**
 *
 * @author Casey
 */
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;

public class BaseballWS {

    public static void main(String[] args) {
        // Location of file to read
        ArrayList<BaseballWSBlueprint> teams = new ArrayList<BaseballWSBlueprint>();
        File file = new File("WorldSeriesWinLose.txt");
        BufferedReader in = null;
        int year = 1903;
        try {
            // create a BufferedReader to use to read in the file
            in = new BufferedReader(new FileReader(file));

            // read in the first entire line from the file
            String line = in.readLine();
            // continue until the line is null (ie you are at the end of the file)
            while (line != null) {
                // create a StringTokenizer instance that will break the line apart at each , symbols
                // NOTE: the second parameter is the symbols used to separate fields
                StringTokenizer t = new StringTokenizer(line, ",");

                // it gets here if it is a baseball object.
                // Now get each token and put it in a variable
                String winner = t.nextToken().trim();
                String league = t.nextToken().trim();
                String loser = t.nextToken().trim();
                // create a Baseball instance for the data
                if ((year == 1904) || (year == 1994)) {
                    year++;
                }
                BaseballWSBlueprint b = new BaseballWSBlueprint(year, winner, league, loser);
                // add the instance to the ArrayList
                teams.add(b);
                year++;
                //System.out.println(b.toString());
                // read in the next line
                line = in.readLine();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (EOFException ex) {
            System.out.println("End of file reached.");
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } finally {
            try {
                in.close();
            } catch (Exception e) {
            }   // note the {} - means "do nothing".  should be closed anyway.
        }
        // create HashMap to store String keys and Integer values
        Map< String, Integer> myMapWinners = new HashMap< String, Integer>();
        Map< String, Integer> myMapLeague = new HashMap< String, Integer>();
        Map< String, Integer> myMapLosers = new HashMap< String, Integer>();

        createMapWinners(myMapWinners, teams); // create map based on file
        createMapLeague(myMapLeague, teams);
        createMapLosers(myMapLosers, teams);

        displayMap(myMapWinners, "Winners:"); // display map content
        displayMapLeague(myMapLeague, "League:"); // display map content
        displayMap(myMapLosers, "Losers:"); // display map content
    } // end main
// create map from file

    private static void createMapWinners(Map< String, Integer> map, ArrayList<BaseballWSBlueprint> teams) {
        // processing input text 
        for (BaseballWSBlueprint token : teams) {
            String wsline = token.getWinner(); // get word

            // if the map contains the word
            if (map.containsKey(wsline)) // is word in map
            {
                int count = map.get(wsline); // get current count
                map.put(wsline, count + 1); // increment count
            } // end if
            else {
                map.put(wsline, 1); // add new word with a count of 1 to map
            }
        } // end for
    } // end method createMap

    private static void createMapLeague(Map< String, Integer> map, ArrayList<BaseballWSBlueprint> teams) {
        // processing input text 
        for (BaseballWSBlueprint token : teams) {
            String wsline = token.getLeague(); // get word

            // if the map contains the word
            if (map.containsKey(wsline)) // is word in map
            {
                int count = map.get(wsline); // get current count
                map.put(wsline, count + 1); // increment count
            } // end if
            else {
                map.put(wsline, 1); // add new word with a count of 1 to map
            }
        } // end for
    } // end method createMap

    private static void createMapLosers(Map< String, Integer> map, ArrayList<BaseballWSBlueprint> teams) {
        // processing input text 
        for (BaseballWSBlueprint token : teams) {
            String wsline = token.getLoser(); // get word

            // if the map contains the word
            if (map.containsKey(wsline)) // is word in map
            {
                int count = map.get(wsline); // get current count
                map.put(wsline, count + 1); // increment count
            } // end if
            else {
                map.put(wsline, 1); // add new word with a count of 1 to map
            }
        } // end for
    } // end method createMap

    // display map content
    private static void displayMap(Map< String, Integer> map, String type) {
        System.out.println(type);

        // generate output for greatest key in map
        Entry<String, Integer> maxEntry = null;
        for (Map.Entry<String, Integer> keys : map.entrySet()) {
            if (maxEntry == null || keys.getValue() > maxEntry.getValue()) {
                maxEntry = keys;
            }
        }
        System.out.println(maxEntry);
    } // end method displayMap

    private static void displayMapLeague(Map< String, Integer> map, String type) {
        System.out.println(type);

        // generate output for greatest key in map
        for (Map.Entry<String, Integer> keys : map.entrySet()) {
            System.out.println(keys.getKey() + ": " + keys.getValue());
        }
    } // end method displayMap
}