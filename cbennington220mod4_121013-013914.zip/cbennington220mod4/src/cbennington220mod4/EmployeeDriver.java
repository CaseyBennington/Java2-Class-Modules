package cbennington220mod4;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class EmployeeDriver {

    public static void main(String[] args) {

        int choice = 0;
        ArrayList<Employee> emp = new ArrayList<Employee>();

        try {
            while (choice >= 0) {
                choice = menu();
                if (choice == 1) {
                    emp = inputData();
                } else if (choice == 2) {
                    emp = readData();
                } else if (choice == 3) {
                    printData(emp);
                } else if (choice == 4) {
                    saveData(emp);
                } else if (choice == 5) {
                    System.out.println("Bye!!!!!");
                    choice = -1;
                }
            }  // end while
        } catch (IllegalArgumentException iae) {
            //iae.printStackTrace();
            System.err.println("You didn't read the directions!  That isn't a valid entry.  Try Again!!");
        }
    }

    public static int menu() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("\nChoice:");
        System.out.println("   1.  Input employees from keyboard");
        System.out.println("   2.  Read employees from file");
        System.out.println("   3.  Print employees");
        System.out.println("   4.  Save employee data");
        System.out.println("   5.  Quit!! ");
        System.out.println("\nCHOICE:");
        int value = keyboard.nextInt();
        return value;

    }

    public static ArrayList<Employee> inputData() {
        Scanner keyboard = new Scanner(System.in);
        ArrayList<Employee> emp = new ArrayList<Employee>();
        boolean more = true;
        while (more) {
            System.out.println("Employee name: ");
            String who = keyboard.nextLine();
            System.out.println("Salary: ");
            double amt = keyboard.nextDouble();
            Employee em = new Employee(who, amt);
            emp.add(em);

            System.out.println("More (true/false)");
            more = keyboard.nextBoolean();
            keyboard.nextLine();
        }
        return emp;
    }

    public static void printData(ArrayList<Employee> e) {
        System.out.println("Employees:");
        for (int i = 0; i < e.size(); i++) {
            System.out.println(e.get(i).toString());
        }
    }

    public static ArrayList<Employee> readData() {
        try {
            ArrayList<Employee> emp;
            try (Scanner employeeFile = new Scanner(new File("employees.dat"))) {
                emp = new ArrayList<Employee>();
                while (employeeFile.hasNext()) {
                    // Read a record from the file.
                    // First, read the name.
                    String who = employeeFile.nextLine();

                    // Next read the salary.
                    Double amt = employeeFile.nextDouble();
                    // Read the newline that was left by nextInt...                 
                    employeeFile.nextLine();
                    Employee em = new Employee(who, amt);
                    emp.add(em);
                }
            }
            System.out.println("The data was read from the file into the array list");

            return emp;

        } catch (Exception ex) {
            //ex.printStackTrace();
            System.err.println("Try Again!!");
            return null;
        } 
    }

    public static void saveData(ArrayList<Employee> e) {
        // Open a file named employees.dat.
        try {
            try (PrintWriter employeeFile = new PrintWriter("employees.dat")) {
                for (int counter = 0; counter < e.size(); counter++) {
                    Employee emp = e.get(counter);
                    employeeFile.println(emp.getName());
                    employeeFile.println(emp.getSalary());
                }
            }
            System.out.println("The data was saved to a file");

        } catch (Exception ex) {
            //ex.printStackTrace();
            System.err.println("Try Again!!");
        }
    }
}