package cbennington220mod4;

import java.util.*;

public class AccountDriverPartB {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        try {
            System.out.println("Account number: ");
            int num = scan.nextInt();
            System.out.println("Balance: ");
            double bal = scan.nextDouble();
            scan.nextLine();
            System.out.println("Last: ");
            String last = scan.nextLine();
            System.out.println("First: ");
            String first = scan.nextLine();
            if (bal < 0) {
                throw new NegativeBalanceException("Balance cannot be negative.");
            }

            Account acct = new Account(num, bal, last, first);

            print(acct);

            System.out.println("How much would you like to deposit?");
            int dep = scan.nextInt();
            if (dep < 0) {
                throw new NegativeDepositException("Deposit cannot be less than 0.");
            } else {
                acct.deposit(dep);
            }

            print(acct);
            System.out.println("How much would you like to withdraw?  Fee is $10");
            int withdrawl = scan.nextInt();
            if (withdrawl > acct.getBalance()) {
                throw new InvalidWithdrawlException("Cannot withdraw more than your balance.");
            } else {
                acct.withdraw(withdrawl, 10);
            }
            print(acct);
        } catch (NegativeBalanceException nbe) {
            //e.printStackTrace();
            System.out.println("Balance cannot be negative.");
        } catch (NegativeDepositException nde) {
            //e.printStackTrace();
            System.out.println("Deposit cannot be less than 0.");
        } catch (InvalidWithdrawlException iwe) {
            //e.printStackTrace();
            System.out.println("Cannot withdraw more than your balance.");
        }
    }

    public static void print(Account a) {
        System.out.println(a.toString());
    }
}

class NegativeBalanceException extends Exception {

    public NegativeBalanceException() {
        super();
    }

    public NegativeBalanceException(String s) {
        super(s);
    }
}

class NegativeDepositException extends Exception {

    public NegativeDepositException() {
        super();
    }

    public NegativeDepositException(String s) {
        super(s);
    }
}

class InvalidWithdrawlException extends Exception {

    public InvalidWithdrawlException() {
        super();
    }

    public InvalidWithdrawlException(String s) {
        super(s);
    }
}