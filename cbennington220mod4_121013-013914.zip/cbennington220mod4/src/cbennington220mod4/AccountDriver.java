package cbennington220mod4;

import java.util.*;

public class AccountDriver {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        try {
            System.out.println("Account number: ");
            int num = scan.nextInt();
            System.out.println("Balance: ");
            double bal = scan.nextDouble();
            scan.nextLine();
            System.out.println("Last: ");
            String last = scan.nextLine();
            System.out.println("First: ");
            String first = scan.nextLine();
            if (bal < 0) {
                throw new IllegalArgumentException("Balance cannot be negative.");
            }

            Account acct = new Account(num, bal, last, first);

            print(acct);

            System.out.println("How much would you like to deposit?");
            int dep = scan.nextInt();
            if (dep < 0) {
                throw new IllegalArgumentException("Deposit cannot be less than 0.");
            } else {
                acct.deposit(dep);
            }

            print(acct);
            System.out.println("How much would you like to withdraw?  Fee is $10");
            int withdrawl = scan.nextInt();
            if (withdrawl > acct.getBalance()) {
                throw new IllegalArgumentException("Cannot withdraw more than your balance.");
            } else {
                acct.withdraw(withdrawl, 10);
            }
            print(acct);
        } catch (IllegalArgumentException iae) {
            //e.printStackTrace();
            System.out.println("Try again!");
        }
    }

    public static void print(Account a) {
        System.out.println(a.toString());
    }
}