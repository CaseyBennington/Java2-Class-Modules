package cbennington220mod1;

import java.text.NumberFormat;

/**
 * @author Casey
 */
public class Product {

    private String name;
    private double priceEach;
    private int numInStock;

    public Product() {
    }

    public Product(String n, double p, int s) {
        name = n;
        priceEach = p;
        numInStock = s;
    }

    @Override
    public String toString() {
        NumberFormat nf = NumberFormat.getCurrencyInstance();
        String s = name + " costs " + nf.format(priceEach) + " and there are " + numInStock + " in stock";
        s = s + " for a total value of " + nf.format(calcInvValue());
		return s;
    }

    public String toStringC() {
        return name + " Cost:" + priceEach;
    }

    public double calcInvValue() {
        return numInStock * priceEach;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumInStock() {
        return numInStock;
    }

    public void setNumInStock(int numInStock) {
        this.numInStock = numInStock;
    }

    public double getPriceEach() {
        return priceEach;
    }

    public void setPriceEach(double priceEach) {
        this.priceEach = priceEach;
    }
}
