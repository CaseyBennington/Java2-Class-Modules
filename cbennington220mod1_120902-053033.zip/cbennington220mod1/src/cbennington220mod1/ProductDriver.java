package cbennington220mod1;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Casey
 */
public class ProductDriver {

    public static void main(String[] args) {
        NumberFormat nf = NumberFormat.getCurrencyInstance();
        double sales = 0;
        ArrayList<Product> pro = new ArrayList<Product>();
        loadData(pro);

        Scanner scan = new Scanner(System.in);

        int value = 0;
        while (value != -999) {
            printData(pro);
            System.out.println("\nWhich choice? (-999) to end");
            try {
                value = scan.nextInt();
                pro.get(value).getNumInStock();  
/**the only way I could figure out to get the exception to be thrown for an arrayoutofbounds at this point in the code.
 * A letter entry creates an infinite loop, which when going through the debugger, I cannot understand why.
 * It doesn't not seem to be following its own rules after the first iteration.  Maybe you could enlighten me?
 */
                if (value != -999) {
                    value = value - 1;
                    System.out.println("\nHow many do you want?");
                    int numBought = scan.nextInt();
                    if (numBought > pro.get(value).getNumInStock()) {
                        System.out.println("There are not that many in stock.  Sale cancelled!!");
                    } else if (numBought < 0) {
                        System.out.println("That is an invalid entry!");
                    } else {
                        System.out.println("Sold!  The sale has been recorded.");
                        sales = sales + (numBought * pro.get(value).getPriceEach());
                        int newNum = pro.get(value).getNumInStock() - numBought;
                        pro.get(value).setNumInStock(newNum);
                    }
                }
            } catch (Exception e) {
                System.out.println("An invalid entry.");
            }
        }
        System.out.println("Final inventory:");
        printData(pro);
        System.out.println("The total value of inventory sold was " + nf.format(sales));
    }

    public static void loadData(ArrayList<Product> data) {
        data.add(new Product("P1", 2.98, 100));
        data.add(new Product("P2", 4.5, 130));
        data.add(new Product("P3", 9.98, 250));
        data.add(new Product("P4", 4.49, 430));
        data.add(new Product("P5", 6.87, 710));
    }

    public static void printData(ArrayList<Product> data) {
        for (int i = 0; i < data.size(); i++) {
            System.out.println((i + 1) + ".  " + data.get(i).toString());
        }
    }
}