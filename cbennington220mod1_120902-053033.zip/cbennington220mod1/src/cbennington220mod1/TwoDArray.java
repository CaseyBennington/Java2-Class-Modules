package cbennington220mod1;

import java.util.Scanner;

/**
 *
 * @author Casey
 */
public class TwoDArray {
    public static void main(String[] args) {
        char[][] seats = {
            {'A', 'B', 'C', 'D'},
            {'A', 'B', 'C', 'D'},
            {'A', 'B', 'C', 'D'},
            {'A', 'B', 'C', 'D'},
            {'A', 'B', 'C', 'D'},
            {'A', 'B', 'C', 'D'},
            {'A', 'B', 'C', 'D'},};
        Scanner scan = new Scanner(System.in);
        displaySeats(seats);
        char choice = 'A';
        //char choice = input.nextChar();
        while (choice != 'E') {
            menu();
            choice = scan.next().charAt(0);
            if (choice == 'V') {
                displaySeats(seats);
            } else if (choice == 'P') {
                chooseSeat(seats);
            } else if (choice == 'E') {
                System.exit(0);
            } else {
                System.exit(0);
            }
        }

    public static void chooseSeat(char[][] seats) {    //I am getting an unknown error here... It only shows up on NetBeans and not on Eclipse.
        Scanner scan = new Scanner(System.in);
        System.out.println("Please select your available seating.");
        System.out.println();
        System.out.print("What Row(1-7) do you want?");
        int row = scan.nextInt()-1;
        System.out.print("What Seat(1-4) do you want?");
        int column = scan.nextInt()-1;
        try {
            if (seats[row][column] != 'X') { // available seat checking
                seats[row][column] = 'X';
                System.out.println("You just purchased a seat located at Row-" + row + " / Seat-" + column + ".  Thank you.");
            } else {
                System.out.println("This seat is already occupied. Try a different seat");
            }
        } catch (Exception e) {
            System.out.println("Invalid input, start over...");
        }
    }

    static void displaySeats(char[][] seats) {
        System.out.println("*Isle Seating Chart*");
        System.out.println("_____________________");
        System.out.println("---> S-1 S-2 S-3 S-4");

        for (int i = 0; i < 7; i++) {
            System.out.print("R" + (i + 1) + " >  ");
            for (int j = 0; j < 4; j++) {
                System.out.print(seats[i][j] != '\u0000' ? seats[i][j] + "   " : "   ");   //I tried google for this line, but was not very successful.  Are we going to address formatting output very much?
            }
            System.out.println();
        }
    }

    public static void menu() {
        System.out.println("\n(V)iew Seats, (P)urchase Seats, (E)xit:");
    }
}