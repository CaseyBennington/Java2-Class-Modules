package cbennington220mod1;

import java.text.NumberFormat;
import java.util.Scanner;

/**
 *
 * @author Casey
 */
public class SalesCommissions {

    public static void main(String[] args) {
        NumberFormat nf = NumberFormat.getCurrencyInstance();
        int[] comValues = new int[9];

        Scanner scan = new Scanner(System.in);

        double value = 0;
        while (value >= 0) {
            System.out.println("Enter sales amount (negative to end):");
            value = scan.nextInt();
            if (value >= 0) {
                value = 200 + (value * .09);
                if (value >= 200 && value <= 299) {
                    System.out.println("This salesperson made " + nf.format(value));
                    comValues[0]++;
                } else if (value >= 300 && value <= 399) {
                    System.out.println("This salesperson made " + nf.format(value));
                    comValues[1]++;
                } else if (value >= 400 && value <= 499) {
                    System.out.println("This salesperson made " + nf.format(value));
                    comValues[2]++;
                } else if (value >= 500 && value <= 599) {
                    System.out.println("This salesperson made " + nf.format(value));
                    comValues[3]++;
                } else if (value >= 600 && value <= 699) {
                    System.out.println("This salesperson made " + nf.format(value));
                    comValues[4]++;
                } else if (value >= 700 && value <= 799) {
                    System.out.println("This salesperson made " + nf.format(value));
                    comValues[5]++;
                } else if (value >= 800 && value <= 899) {
                    System.out.println("This salesperson made " + nf.format(value));
                    comValues[6]++;
                } else if (value >= 900 && value <= 999) {
                    System.out.println("This salesperson made " + nf.format(value));
                    comValues[7]++;
                } else if (value >= 1000) {
                    System.out.println("This salesperson made " + nf.format(value));
                    comValues[8]++;
                }
            }
        }
        System.out.printf("%s%17s\n", "Range", "Number");
        for (int counter = 0; counter < comValues.length; counter++) {
            if (counter == 8) {
                System.out.printf("$%4d and over: ", 1000);
            } else {
                System.out.printf("$%02d-$%02d: ", (counter + 2) * 100, (counter + 2) * 100 + 99);
            }
            System.out.print("        " + comValues[counter]);
            System.out.println();
        }
    }
}